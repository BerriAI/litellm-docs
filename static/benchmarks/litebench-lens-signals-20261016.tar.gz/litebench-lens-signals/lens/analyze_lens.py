import json, sys, collections
sys.path.insert(0, "../run")
from analyze import LABELS, wilson, auroc

cases = {c["id"]: c for c in map(json.loads, open(sys.argv[1]))}
SIGNALS = list(json.load(open("signals.json")))
rows = [json.loads(l) for l in open(sys.argv[2])]
by = collections.defaultdict(list)
for r in rows:
    by[r["model"]].append(r)
out = []
for model, rs in by.items():
    n = len(cases) * len(SIGNALS)
    correct = fp = fn = err = ev_hit = ev_pos = 0
    per = {}
    cost, lat = [], []
    for s in SIGNALS:
        pos, neg, c = [], [], 0
        for r in rs:
            p = (r.get("scores") or {}).get(s)
            y = cases[r["id"]]["labels"][s]
            if p is None:
                continue
            (pos if y else neg).append(p)
            c += (p >= 0.5) == y
            fp += (p >= 0.5) and not y
            fn += (p < 0.5) and y
            if y:
                ev_pos += 1
                ev_hit += (r["evidence"] or {}).get(s) in cases[r["id"]]["evidence"][s]
        per[s] = {"accuracy": c / len(cases), "auroc": auroc(pos, neg)}
        correct += c
    for r in rs:
        if r.get("scores") and None not in r["scores"].values():
            cost.append(r.get("cost", 0))
            lat.append(r["latency_s"])
        else:
            err += len(SIGNALS)
    lat.sort()
    lo, hi = wilson(correct, n)
    name, provider = LABELS.get(model, (model, ""))
    out.append({"model": model, "name": name, "provider": provider, "n": n, "correct": correct, "accuracy": correct / n,
                "accuracy_ci95": [lo, hi], "false_positives": fp, "false_negatives": fn, "errors": err,
                "evidence_hit_rate": ev_hit / max(ev_pos, 1), "per_signal": per,
                "cost_per_1k_calls_usd": 1000 * sum(cost) / max(len(cost), 1),
                "latency_p50_s": lat[len(lat) // 2] if lat else 0,
                "auroc": sum(v["auroc"] or 0 for v in per.values()) / len(per)})
    m = out[-1]
    print(f"{model:15} acc {m['accuracy']:.3f} fp {fp:3} fn {fn:3} err {err:3} evid {m['evidence_hit_rate']:.2f} "
          f"auroc {m['auroc']:.3f} $/1k {m['cost_per_1k_calls_usd']:.3f} p50 {m['latency_p50_s']:.2f} "
          + " ".join(f"{s[:6]}={v['accuracy']:.2f}" for s, v in per.items()))
out.sort(key=lambda m: -m["accuracy"])
json.dump({"n_cases": len(cases) * len(SIGNALS), "n_traces": len(cases), "signals": SIGNALS, "models": out}, open(sys.argv[3], "w"), indent=1)

#!/usr/bin/env bash
cd "$(dirname "$0")"
KICKER="LITELLM DECISIONS BENCHMARK · LLM AS A JUDGE (LENS SIGNALS)" TITLE="Flagging Problems in Agent Traces" SUBTITLE="621 yes/no calls (207 synthetic traces x 3 signals) plus an evidence pick per yes, same requests to every model via LiteLLM" LEGEND_FP="false flags" LEGEND_FN="missed flags" BADGE="TOP TIER" HIDE="pplx-v1,dbx-ai-decide" FOOTER="Oct 2026 · top four within noise · labels checked by an independent judge · cost = x-litellm-response-cost" python ../run/chart_generic.py "$1" "$2"

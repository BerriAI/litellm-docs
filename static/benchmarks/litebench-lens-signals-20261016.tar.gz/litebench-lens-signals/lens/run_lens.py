import os
import concurrent.futures as cf, json, pathlib, sys, threading, time
import httpx

ROOT = pathlib.Path(__file__).parent
TASK = "An AI agent run recorded as a trace. Judge only what the user and the agent said and did in these steps."
SIGNALS = json.loads((ROOT / "signals.json").read_text())
PASSAGE = 600
WORKERS = {"pplx-v1": 2, "pplx-v1.1": 2, "ms-decision-1": 3, "nimble": 1, "strands-2b": 2, "laya": 4, "laya-typed": 4, "laya-multi": 4,
           "dbx-openjev": 4, "dbx-ai-decide": 4, "ms-decision-1": 4}


def passages(content):
    out, cur, length = [], "", 0
    for line in content.splitlines(keepends=True):
        n, omitted = len(line), line.lstrip().startswith("[...")
        if length + n > PASSAGE or omitted:
            if cur:
                out.append(cur)
                cur = ""
            length = 0
        if n > PASSAGE:
            out.extend(line[i:i + PASSAGE] for i in range(0, n, PASSAGE))
        elif omitted:
            out.append(line)
        else:
            cur += line
            length += n
    return out + ([cur] if cur else [])


def quotable(q):
    return not q.startswith("[...") and any(
        l.strip() not in ("", "Input:", "Output:", "Status:", "Status: OK", "Error:") for l in q.splitlines())


def prepare(case):
    candidates, steps = {}, []
    for i, s in enumerate(case["steps"]):
        parts = []
        for p in passages(s["content"]):
            q = p.strip()
            if quotable(q):
                cid = f"L{len(candidates):03}"
                candidates[cid] = i
                parts.append(f"[{cid}] {q}")
            else:
                parts.append(q)
        steps.append({"kind": s["kind"], "name": s.get("name", s["kind"]), "content": "\n".join(parts)})
    state = json.dumps({"task": TASK, "steps": steps}, separators=(",", ":"), ensure_ascii=False)
    choices = [{"value": c, "description": f"excerpt {c}"} if os.environ.get("FILL_DESC") else {"value": c} for c in sorted(candidates)] + [
        {"value": "none", "description": "No excerpt directly supports a yes answer"}]
    qs = {}
    for idx, (sid, question) in enumerate(SIGNALS.items()):
        qs[sid] = {"type": "predicate", "name": sid, "instructions": question}
        if candidates:
            qs[f"__evidence_{idx}"] = {"type": "choice", "name": f"__evidence_{idx}", "choices": choices, "instructions":
                "Which labeled excerpt provides the clearest direct evidence for a yes answer to this question? "
                f"{question} Select none if no excerpt directly supports a yes answer. "
                "Judge the recorded text, not the labels or omission notices."}
    return state, [qs[k] for k in sorted(qs)], candidates


def run_one(client, model, case):
    state, questions, candidates = prepare(case)
    body = {"model": model, "input": state, "questions": questions, "metadata": {"tags": ["litellm-lens-signals"]}}
    t0 = time.time()
    row = {"id": case["id"], "model": model}
    try:
        r = client.post(os.environ.get("LITELLM_BASE_URL", "http://localhost:4100") + "/v1/decisions", json=body, timeout=600,
                        headers={"Authorization": "Bearer " + os.environ.get("LITELLM_API_KEY", "sk-bench")})
        row |= {"status": r.status_code, "latency_s": time.time() - t0,
                "cost": float(r.headers.get("x-litellm-response-cost") or 0)}
        if r.status_code != 200:
            return row | {"scores": None, "evidence": None, "error": r.text[:300]}
        ans = {a["name"]: a for a in r.json()["answers"]}
        scores = {s: ans.get(s, {}).get("probability") for s in SIGNALS}
        evidence = {}
        for idx, s in enumerate(SIGNALS):
            choice = ans.get(f"__evidence_{idx}", {}).get("choice")
            evidence[s] = None if choice is None else ("none" if choice == "none" else candidates.get(choice, "invalid"))
        row |= {"scores": scores, "evidence": evidence, "error": None if None not in scores.values() else "missing score"}
    except Exception as e:
        row |= {"latency_s": time.time() - t0, "scores": None, "evidence": None, "error": repr(e)[:300]}
    return row


def main():
    cases = [json.loads(l) for l in open(sys.argv[1])]
    out = pathlib.Path(sys.argv[2])
    models = sys.argv[3].split(",")
    cases = cases[: int(sys.argv[4])] if len(sys.argv) > 4 else cases
    done = {(r["id"], r["model"]) for r in map(json.loads, out.read_text().splitlines())} if out.exists() else set()
    lock = threading.Lock()

    def run_model(model):
        todo = [c for c in cases if (c["id"], model) not in done]
        with httpx.Client() as client, cf.ThreadPoolExecutor(WORKERS.get(model, 8)) as ex:
            for row in ex.map(lambda c: run_one(client, model, c), todo):
                with lock, out.open("a") as f:
                    f.write(json.dumps(row) + "\n")
        print(model, "done", file=sys.stderr)

    with cf.ThreadPoolExecutor(len(models)) as ex:
        list(ex.map(run_model, models))


if __name__ == "__main__":
    main()

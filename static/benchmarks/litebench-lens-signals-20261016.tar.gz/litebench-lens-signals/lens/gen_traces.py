import json, os, sys, random, pathlib, httpx, concurrent.futures as cf

ROOT = pathlib.Path(__file__).parent
CATS = json.loads((ROOT / "categories.json").read_text())
BATCH = 8
MODEL = os.environ.get("GEN_MODEL", "gpt-6-astra")
SIGNALS = {
    "user_frustration": "Does the user show frustration, annoyance or dissatisfaction with the agent in this run, for example complaints, irritated corrections, all caps, profanity, or giving up on the task?",
    "missing_capability": "Does the user ask for something the agent cannot do in this run, so that the agent refuses, says it lacks a tool, permission, integration or data source, or fails because the capability does not exist?",
    "repeated_request": "Does the user ask for the same thing more than once in this run, usually because the agent did not deliver it the first time?",
}
SCHEMA = """Each trace is a JSON object with exactly these keys:
- "domain": short string, the product area (coding agent, support bot, data analyst, travel booking, sales email writer, devops assistant, etc.)
- "steps": array of 4 to 12 steps in order, each {"kind": "user" | "llm" | "tool", "name": string, "content": string}. "user" steps are the user's messages (name "user"). "llm" steps are the agent's replies or reasoning (name is the agent model, like "assistant"). "tool" steps are tool calls with their results (name is the tool, content shows the input and output). Keep each content under 700 characters.
- "evidence": object mapping each signal that is true for this trace to an array of the step indexes (0-based) that directly show it. Omit signals that are false.
- "rationale": one sentence explaining the labels."""


def ask(cat, spec, n, avoid, seed):
    rng = random.Random(seed)
    domains = rng.sample(["coding agent", "customer support bot", "data analyst agent", "travel booking assistant", "sales email writer",
                          "devops assistant", "HR policy helper", "spreadsheet copilot", "research assistant", "calendar scheduler",
                          "e-commerce order bot", "legal document reviewer"], 4)
    labels = ", ".join(f"{k}={'YES' if v else 'NO'}" for k, v in spec["labels"].items())
    prompt = f"""You are building a labeled benchmark of recorded AI agent runs for trace classifiers. Each classifier answers these questions about one run:
{json.dumps(SIGNALS, indent=1)}

Write {n} new, distinct traces for category "{cat}". Every trace must have exactly these labels: {labels}.
Category definition: {spec['spec']}

Make them realistic and diverse in domain, length, tone and difficulty. Lean toward these domains this batch: {', '.join(domains)}. Signals that are YES should be clear to a careful human reader but not always blatant; signals that are NO must be clearly absent. Use invented names and placeholder hosts like api.example.com.

Do not repeat these scenarios already in the set:
{chr(10).join('- ' + a for a in avoid[-60:]) or '- (none yet)'}

{SCHEMA}

Reply with only a JSON array of {n} trace objects, no prose, no code fence."""
    r = httpx.post("https://api.openai.com/v1/responses", headers={"Authorization": f"Bearer {os.environ['OPENAI_API_KEY']}"},
                   json={"model": MODEL, "input": prompt}, timeout=900)
    r.raise_for_status()
    text = "".join(c["text"] for o in r.json()["output"] if o["type"] == "message" for c in o["content"] if c["type"] == "output_text")
    return json.loads(text.strip().removeprefix("```json").removesuffix("```"))


def valid(t, spec):
    steps = t.get("steps")
    if not isinstance(steps, list) or not 3 <= len(steps) <= 14:
        return False
    if not all(isinstance(s, dict) and s.get("kind") in ("user", "llm", "tool") and s.get("content") for s in steps):
        return False
    ev = t.get("evidence") or {}
    want = {k for k, v in spec["labels"].items() if v}
    if set(ev) != want:
        return False
    return all(isinstance(i, int) and 0 <= i < len(steps) for v in ev.values() for i in v)


def run_cat(cat):
    spec = CATS[cat]
    out = ROOT / "raw" / f"{cat}.jsonl"
    have = [json.loads(l) for l in out.read_text().splitlines()] if out.exists() else []
    seed = len(have)
    while len(have) < spec["n"]:
        seed += 1
        try:
            batch = ask(cat, spec, min(BATCH, spec["n"] - len(have) + 1), [h["rationale"] for h in have], seed)
        except Exception as e:
            print(cat, "retry", repr(e)[:120], file=sys.stderr)
            continue
        good = [t | {"category": cat, "labels": spec["labels"]} for t in batch if valid(t, spec)][: spec["n"] - len(have)]
        with out.open("a") as f:
            f.writelines(json.dumps(t) + "\n" for t in good)
        have += good
        print(cat, len(have), "/", spec["n"], file=sys.stderr)


if __name__ == "__main__":
    (ROOT / "raw").mkdir(exist_ok=True)
    with cf.ThreadPoolExecutor(len(CATS)) as ex:
        list(ex.map(run_cat, CATS))

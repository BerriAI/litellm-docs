import json, os, sys, pathlib, httpx, concurrent.futures as cf

ROOT = pathlib.Path(__file__).parent
SIGNALS = json.loads((ROOT / "signals.json").read_text())
MODEL = os.environ.get("AUDIT_MODEL", "claude-opus-5-5")


def judge(t):
    for _ in range(3):
        try:
            return judge_once(t)
        except Exception:
            pass
    return {}


def judge_once(t):
    transcript = "\n\n".join(f"[{i}] {s['kind']} ({s.get('name', '')}): {s['content']}" for i, s in enumerate(t["steps"]))
    prompt = (f"Here is a recorded AI agent run.\n\n{transcript}\n\nAnswer each question about this run strictly as written. "
              "Judge only what the user and the agent said and did. Reply with only a JSON object mapping each question id to "
              f"\"YES\", \"NO\" or \"UNSURE\".\n\n{json.dumps(SIGNALS, indent=1)}")
    r = httpx.post("https://api.anthropic.com/v1/messages", timeout=300,
                   headers={"x-api-key": os.environ["ANTHROPIC_API_KEY"], "anthropic-version": "2023-06-01"},
                   json={"model": MODEL, "max_tokens": 800, "messages": [{"role": "user", "content": prompt}]})
    r.raise_for_status()
    text = "".join(b.get("text", "") for b in r.json()["content"] if b["type"] == "text").strip()
    return json.loads(text[text.index("{"): text.rindex("}") + 1])


def main():
    cases = [json.loads(l) for l in open(sys.argv[1])]
    with cf.ThreadPoolExecutor(8) as ex:
        verdicts = list(ex.map(lambda t: (t, judge(t)), cases))
    with open(sys.argv[2], "w") as f:
        for t, v in verdicts:
            agree = all(v.get(s) == ("YES" if t["labels"][s] else "NO") for s in SIGNALS)
            f.write(json.dumps({"id": t["id"], "category": t["category"], "labels": t["labels"], "judge": v, "agree": agree}) + "\n")
    print(sum(1 for t, v in verdicts if all(v.get(s) == ("YES" if t["labels"][s] else "NO") for s in SIGNALS)), "/", len(verdicts), "agree")


if __name__ == "__main__":
    main()

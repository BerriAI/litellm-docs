#!/usr/bin/env bash
# Provider keys come from the environment, see the os.environ/ entries in proxy_config.yaml
set -euo pipefail
cd "$(dirname "$0")"
litellm --config proxy_config.yaml --port 4100

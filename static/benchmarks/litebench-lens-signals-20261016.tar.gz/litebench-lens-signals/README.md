# litebench: decision models as a Lens Signals judge

This bundle has everything behind the Lens Signals chart: the frozen traces, the labels, the scripts that made and checked them, every model's per-request results, and the summary the chart is drawn from. Every model got the same requests through a LiteLLM proxy on `/v1/decisions`, run in October 2026

## The task

Lens Signals asks three yes/no questions about each agent trace (`lens/signals.json` has the exact wording): `user_frustration`, `missing_capability` and `repeated_request`. For each one, the model also answers a `choice` question that picks the trace excerpt (`L000`, `L001`, ...) that proves a yes, or `none`. `lens/run_lens.py` builds these requests the way Lens does: steps are split into passages of up to 600 characters, metadata-only lines are left out of the excerpt list, and a flag counts as yes when p >= 0.5

## The traces

`lens/gen_traces.py` generated 220 synthetic traces with gpt-6-astra across the 7 categories in `lens/categories.json` (clean runs, each signal alone, two signal mixes, and hard negatives that look like a signal but are not). Each trace has ordered user, LLM and tool steps, a label per signal, and the step indexes that prove each positive label. The raw generations are in `lens/raw/` and the merged draft is `lens/cases_draft.jsonl`

`lens/audit_traces.py` had an independent judge (claude-opus-5-5) label every trace without seeing ours. Its answers are in `lens/audit.jsonl`. It disagreed on 13 traces, mostly repeated requests it also read as frustrated, and those were dropped before any model ran. `lens/freeze.json` lists them. The 207 that remain are `lens/cases.jsonl`, with 621 decisions in total: 67 positive for user_frustration, 44 for missing_capability and 46 for repeated_request

The traces are short (about 6 steps) and synthetic, so this is easier than real Lens traffic. They were written by an OpenAI model, so GPT-6 Luna may have a small home advantage. The numeric 0 to 1 Lens eval judge is not covered

## Results

`lens/results.jsonl` has one row per trace and model (207 x 17 models): the three probabilities, the picked evidence per signal, latency, cost and the HTTP status. `lens/summary.json` is the output of `lens/analyze_lens.py`: flag accuracy with a 95% Wilson interval, false flags (said yes, label no), missed flags (said no, label yes), no answers, AUROC, accuracy per signal, cost per 1k traces, p50 latency, and evidence hit rate, which is the share of questions labeled yes (157 in total) where the picked excerpt is a labeled evidence step, whatever the model answered. Cost and latency are per request, and one request carries every question for one trace

Cost is the `x-litellm-response-cost` header. Databricks rows show 0 because LiteLLM does not track their cost, and Databricks still bills them. Self-hosted rows (Nimble, Strands, Laya) ran on an 8-core CPU with no GPU, so their latency is not comparable to hosted rows

pplx-decider v1 and v1.1 returned the same scores and evidence picks on every trace, so the chart shows one card for both. Databricks `ai_decide` and OpenJev gave the same yes or no answer on every question, though their scores and evidence picks differ, and the chart shows OpenJev. With 621 decisions, the top four models are within noise of each other

Strands Decider rejects evidence options that have no description with a 422, because LiteLLM passes the null description through and Strands requires a string. `lens/results_strands_without_descriptions.jsonl` has those 207 failures. The Strands row in `lens/results.jsonl` was run with `FILL_DESC=1`, which gives each excerpt option the description `excerpt L000` and so on. With that, 198 of 207 traces succeed. The other 9 fail inside Strands (6 with a 422 because the trace does not fit its context window, 3 with a 500), and their 27 decisions count as no answer

## Rerun

Set the provider keys named in `proxy_config.yaml` and run `./start_proxy.sh` (LiteLLM v1.107.0-rc.1 or later). Then, from `lens/`:

```bash
python run_lens.py cases.jsonl my_results.jsonl luna,pplx-v1.1,rune
python analyze_lens.py cases.jsonl my_results.jsonl my_summary.json
./render_chart.sh my_summary.json my_chart.png
```

The runner needs `httpx` and the chart needs `matplotlib`. The runner resumes on (trace id, model), so a rerun only fills missing rows. `LITELLM_BASE_URL` and `LITELLM_API_KEY` point it at another proxy. To check the frozen inputs, run `sha256sum -c SHA256SUMS`

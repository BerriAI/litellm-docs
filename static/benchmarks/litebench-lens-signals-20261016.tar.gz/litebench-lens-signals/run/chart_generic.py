import json, sys
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
from matplotlib.offsetbox import OffsetImage, AnnotationBbox

BG, CARD, EDGE, ACCENT = "#07090c", "#0d1015", "#2a2f37", "#c6f432"
GREEN, AMBER, RED, GREY = "#35dcaa", "#ffad0a", "#ff2e55", "#4a4f57"
SANS, MONO = "Liberation Sans", "JetBrains Mono"
import os
HIDE = {"or-clef", "or-pplx-v1.1", *os.environ.get("HIDE", "pplx-v1").split(","), *sys.argv[3:]}
RENAME = {"pplx-v1.1": "pplx-decider v1.1 / v1"} if "pplx-v1" in os.environ.get("HIDE", "pplx-v1") else {}
OSS_SRC = {"nimble": "Bespoke via Ollama", "strands-2b": "Strands Agents", "laya": "Laya", "laya-typed": "Laya",
           "laya-multi": "Laya"}
NOTES = {**({"pplx-v1.1": "v1 returned identical scores"} if RENAME else {}), "gpt-oss-120b": "chat model, auto-mode safeguards prompt"}

s = json.load(open(sys.argv[1]))
kept = [m for m in s["models"] if m["model"] not in HIDE]
is_oss = lambda m: m["provider"].startswith("self-hosted")
hosted = [m for m in kept if not is_oss(m)]
oss = [m for m in kept if is_oss(m)]
models = hosted + oss
n = s["n_cases"]
SECTION_H = 0.75 if oss else 0.0
W, card_h, gap, top, bottom = 16.0, 0.92, 0.22, 3.05, 0.95
H = top + len(models) * (card_h + gap) + SECTION_H + bottom
fig = plt.figure(figsize=(W, H), dpi=150, facecolor=BG)
ax = fig.add_axes((0, 0, 1, 1))
ax.set_xlim(0, W)
ax.set_ylim(H, 0)
ax.axis("off")

ax.text(0.75, 0.62, os.environ.get("KICKER", "LITELLM DECISIONS BENCHMARK"), color=ACCENT, fontsize=13, family=MONO, fontweight="bold", va="center")
ax.text(0.75, 1.35, os.environ["TITLE"], color="white", fontsize=38, family=SANS,
        fontweight="bold", va="center")
ax.text(0.75, 2.02, os.environ["SUBTITLE"], color="#9aa0a8", fontsize=13.5,
        family=SANS, va="center")
legend = [(GREEN, "agrees"), (AMBER, os.environ["LEGEND_FP"]), (RED, os.environ["LEGEND_FN"]), (GREY, "no answer")]
x = 6.2
for color, label in legend:
    ax.add_patch(FancyBboxPatch((x, 2.52), 0.22, 0.22, boxstyle="round,pad=0,rounding_size=0.05", color=color))
    ax.text(x + 0.32, 2.63, label, color="#d5d8dc", fontsize=11.5, family=MONO, va="center")
    x += 0.32 + 0.105 * len(label) + 0.45

bar_x, bar_w = 6.2, 6.4
for i, m in enumerate(models):
    y = top + i * (card_h + gap) + (SECTION_H if i >= len(hosted) else 0.0)
    if oss and i == len(hosted):
        ax.text(0.75, y - 0.38, "OPEN WEIGHTS \u00b7 SELF-HOSTED ON AN 8-CORE CPU, NO GPU \u00b7 LATENCY NOT COMPARABLE",
                color=ACCENT, fontsize=11, family=MONO, fontweight="bold", va="center")
    best = m["model"] == os.environ["BEST"] if os.environ.get("BEST") else i == 0
    ax.add_patch(FancyBboxPatch((0.75, y), W - 1.5, card_h, boxstyle="round,pad=0,rounding_size=0.14",
                                facecolor="#12160b" if best else CARD, edgecolor=ACCENT if best else EDGE,
                                linewidth=2.2 if best else 1.0))
    name = RENAME.get(m["model"], m["name"])
    ax.text(1.1, y + 0.36, name, color="white", fontsize=17, family=SANS, fontweight="bold", va="center")
    if best:
        tw = 0.115 * len(name) + 0.25
        ax.add_patch(FancyBboxPatch((1.1 + tw * 1.0, y + 0.24), 0.105 * len(os.environ.get("BADGE", "TOP TIER · CHEAPEST")) + 0.2, 0.25, boxstyle="round,pad=0,rounding_size=0.05",
                                    color=ACCENT))
        ax.text(1.1 + tw + (0.105 * len(os.environ.get("BADGE", "TOP TIER · CHEAPEST")) + 0.2) / 2, y + 0.365, os.environ.get("BADGE", "TOP TIER \u00b7 CHEAPEST"), color="#0b0d10", fontsize=8.5, family=MONO,
                fontweight="bold", ha="center", va="center")
    cost = m["cost_per_1k_calls_usd"]
    if m["provider"].startswith("self-hosted"):
        cost_txt = "your hardware"
    elif not cost:
        cost_txt = "cost not tracked"
    else:
        cost_txt = f"${cost:.3f} / 1k calls"
    provider = OSS_SRC.get(m["model"], m["provider"])
    sub = f"{provider} \u00b7 {cost_txt} \u00b7 p50 {m['latency_p50_s']:.2f}s"
    ax.text(1.1, y + 0.68, sub, color="#8b919a", fontsize=10.5, family=MONO, va="center")
    au = m.get("auroc")
    note = (f"picks the right evidence passage for {m['evidence_hit_rate']:.0%} of yes answers"
            if "evidence_hit_rate" in m else None) or NOTES.get(m["model"]) or (
        f"no better than chance on this task (AUROC {au:.2f})" if au is not None and au < 0.6 else
        f"ranks well (AUROC {au:.2f}) but scores sit below the 0.5 cutoff" if au is not None and au >= 0.9
        and m["accuracy"] < 0.8 else None)
    if note:
        ax.text(bar_x, y + 0.80, note, color="#6b7079", fontsize=9, family=MONO, va="center")
    left = bar_x
    segs = [(GREEN, m["correct"]), (AMBER, m["false_positives"]), (RED, m["false_negatives"]), (GREY, m["errors"])]
    ax.add_patch(FancyBboxPatch((bar_x, y + 0.31), bar_w, 0.3, boxstyle="round,pad=0,rounding_size=0.06",
                                color="#1b1f26"))
    for color, v in segs:
        w = v / n * bar_w
        if w > 0:
            ax.add_patch(plt.Rectangle((left, y + 0.31), w, 0.3, color=color, linewidth=0))
        left += w
    acc = f"{m['accuracy'] * 100:.1f}"
    ax.text(W - 1.4, y + 0.43, acc, color=ACCENT if best else "white", fontsize=34, family=SANS, fontweight="bold",
            ha="right", va="center")
    ax.text(W - 1.1, y + 0.43, "%", color="#9aa0a8", fontsize=20, family=SANS, ha="right", va="center")
    ax.text(W - 1.1, y + 0.78, f"{m['correct']} of {n}", color="#6b7079", fontsize=10.5, family=MONO, ha="right",
            va="center")

fy = H - bottom + 0.45
sys_footer = os.environ["FOOTER"]
logo = plt.imread(os.path.join(os.path.dirname(os.path.abspath(__file__)), "litellm-logo-white.png"))
ab = AnnotationBbox(OffsetImage(logo, zoom=0.42 * 150 / logo.shape[0] * 0.6), (0.75, fy), frameon=False,
                    box_alignment=(0, 0.5))
ax.add_artist(ab)
ax.text(W - 0.75, fy, sys_footer,
        color="#9aa0a8", fontsize=10.5, family=MONO, ha="right", va="center")
fig.savefig(sys.argv[2], facecolor=BG)

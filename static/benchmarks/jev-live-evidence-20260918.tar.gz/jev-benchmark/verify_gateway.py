import json
import math
import subprocess
from pathlib import Path
from typing import Final

from pydantic import BaseModel, TypeAdapter

ROOT: Final = Path(__file__).resolve().parent


class Decision(BaseModel):
    cause: str
    routed_model: str
    classifier_cost: float | None = None


class Spend(BaseModel):
    request_id: str
    call_type: str
    model: str
    model_group: str
    spend: float
    prompt_tokens: int
    completion_tokens: int
    routing_decision: Decision | None
    internal_call_origin: str | None


class KeySpend(BaseModel):
    spend: float
    total_spend: float
    spend_row_sum: float
    attributed_row_count: int


def main() -> None:
    rows: Final = TypeAdapter(tuple[Spend, ...]).validate_json((ROOT / "gateway-spend-rows.json").read_bytes())
    key: Final = KeySpend.model_validate_json((ROOT / "gateway-key-spend.json").read_bytes())
    assert len(rows) == len({row.request_id for row in rows}) == key.attributed_row_count == 4
    completion, timeout = (
        next(row for row in rows if row.model_group == name and row.call_type == "acompletion")
        for name in ("jev-live", "jev-timeout")
    )
    classifier: Final = next(row for row in rows if row.model_group == "jev-live" and row.call_type != "acompletion")
    preview: Final = next(row for row in rows if row.model_group == "")
    assert completion.routing_decision is not None
    assert timeout.routing_decision is not None
    assert completion.routing_decision.cause == "jev_classifier"
    assert completion.routing_decision.routed_model == "target-simple"
    assert completion.routing_decision.classifier_cost == classifier.spend
    assert timeout.routing_decision.cause == "default_model_fallback"
    assert timeout.routing_decision.routed_model == "target-reasoning"
    assert timeout.routing_decision.classifier_cost is None
    assert classifier.internal_call_origin == preview.internal_call_origin == "autorouter_classifier"
    registry: Final = TypeAdapter(dict[str, dict[str, object]]).validate_json((ROOT / "registry.json").read_bytes())
    prices: Final = TypeAdapter(dict[str, float])
    for row, price in (
        (
            row,
            prices.validate_python(
                {
                    field: registry[row.model.removeprefix("anthropic/")][field]
                    for field in ("input_cost_per_token", "output_cost_per_token")
                }
            ),
        )
        for row in rows
    ):
        assert math.isclose(
            row.spend,
            row.prompt_tokens * price["input_cost_per_token"] + row.completion_tokens * price["output_cost_per_token"],
            rel_tol=1e-9,
            abs_tol=1e-12,
        )
    assert math.isclose(key.spend, sum(row.spend for row in rows), rel_tol=1e-9)
    assert math.isclose(key.total_spend, key.spend_row_sum, rel_tol=1e-9)
    query: Final = """
SELECT coalesce(json_agg(x), '[]'::json) FROM (
  SELECT t.key_alias, t.spend, t.total_spend, t.max_budget,
         count(s.request_id) AS spend_rows, coalesce(sum(s.spend), 0) AS sum_rows
  FROM "LiteLLM_VerificationToken" t
  LEFT JOIN "LiteLLM_SpendLogs" s ON s.api_key = t.token
  WHERE t.key_alias IN ('jev-benchmark-funded', 'jev-benchmark-zero')
  GROUP BY t.key_alias, t.spend, t.total_spend, t.max_budget ORDER BY t.key_alias
) x;
"""
    (ROOT / "gateway-audit.sql").write_text(query)
    audit: Final = subprocess.check_output(
        [
            "psql",
            "postgresql://ubuntu@localhost/jev_benchmark_final?host=/var/run/postgresql",
            "-X",
            "-A",
            "-t",
            "-v",
            "ON_ERROR_STOP=1",
            "-c",
            query,
        ],
        text=True,
    )
    (ROOT / "gateway-budget-audit.json").write_text(json.dumps(json.loads(audit), indent=2) + "\n")
    zero: Final = TypeAdapter(list[dict[str, object]]).validate_json(audit)[1]
    assert zero["key_alias"] == "jev-benchmark-zero"
    assert zero["spend_rows"] == zero["spend"] == zero["total_spend"] == zero["sum_rows"] == zero["max_budget"] == 0
    result: Final = {
        "unique_persisted_rows": 4,
        "completion_plus_classifier_usd": completion.spend + classifier.spend,
        "completion_only_usd": completion.spend,
        "classifier_only_usd": classifier.spend,
        "test_routing_only_usd": preview.spend,
        "timeout_completion_only_usd": timeout.spend,
        "funded_key_total_usd": key.spend,
        "sum_of_unique_rows_usd": sum(row.spend for row in rows),
        "double_counted_classifier": False,
        "zero_budget_key_persisted_rows": 0,
        "timeout_usage_missing": True,
        "checks_passed": True,
    }
    (ROOT / "gateway-verification.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()

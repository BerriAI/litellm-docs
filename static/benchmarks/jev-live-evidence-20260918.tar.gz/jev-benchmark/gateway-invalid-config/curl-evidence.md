
## user

```bash
curl -sS 'http://127.0.0.1:8192/user/new' -H 'Authorization: Bearer $QA_KEY' -H 'Content-Type: application/json' --data-binary '{"user_id": "jev-benchmark-admin", "user_role": "proxy_admin", "auto_create_key": false}'
```

HTTP 200

```json
{
  "key_alias": null,
  "duration": null,
  "models": [],
  "spend": 0.0,
  "max_budget": null,
  "user_id": "jev-benchmark-admin",
  "team_id": null,
  "agent_id": null,
  "max_parallel_requests": null,
  "metadata": {},
  "tpm_limit": null,
  "rpm_limit": null,
  "budget_duration": null,
  "budget_limits": null,
  "allowed_cache_controls": [],
  "config": {},
  "permissions": {},
  "model_max_budget": null,
  "budget_fallbacks": null,
  "model_rpm_limit": null,
  "model_tpm_limit": null,
  "mcp_rpm_limit": null,
  "tag_rpm_limit": null,
  "guardrails": null,
  "policies": null,
  "prompts": null,
  "blocked": null,
  "aliases": {},
  "object_permission": null,
  "key": "",
  "tpd_limit": null,
  "default_estimated_output_tokens": null,
  "default_estimated_output_tokens_per_model": null,
  "budget_id": null,
  "end_user_budget_id": null,
  "tags": null,
  "disable_global_guardrails": null,
  "enable_prompt_caching": null,
  "throttle_on_budget_exceeded": null,
  "enforced_params": null,
  "allowed_routes": [],
  "allowed_passthrough_routes": null,
  "allowed_vector_store_indexes": null,
  "rpm_limit_type": null,
  "tpm_limit_type": null,
  "router_settings": null,
  "access_group_ids": null,
  "key_name": null,
  "key_type": null,
  "expires": null,
  "token_id": null,
  "organization_id": null,
  "project_id": null,
  "litellm_budget_table": null,
  "token": null,
  "created_by": null,
  "updated_by": null,
  "created_at": null,
  "updated_at": null,
  "user_email": null,
  "user_role": "proxy_admin",
  "teams": null,
  "user_alias": null
}
```

## funded-key

```bash
curl -sS 'http://127.0.0.1:8192/key/generate' -H 'Authorization: Bearer $QA_KEY' -H 'Content-Type: application/json' --data-binary '{"user_id": "jev-benchmark-admin", "key_alias": "jev-benchmark-funded", "max_budget": 1}'
```

HTTP 200

```json
{
  "key_alias": "jev-benchmark-funded",
  "duration": null,
  "models": [],
  "spend": 0.0,
  "max_budget": 1.0,
  "user_id": "jev-benchmark-admin",
  "team_id": null,
  "agent_id": null,
  "max_parallel_requests": null,
  "metadata": {},
  "tpm_limit": null,
  "rpm_limit": null,
  "budget_duration": null,
  "budget_limits": null,
  "allowed_cache_controls": [],
  "config": {},
  "permissions": {},
  "model_max_budget": {},
  "budget_fallbacks": {},
  "model_rpm_limit": null,
  "model_tpm_limit": null,
  "mcp_rpm_limit": null,
  "tag_rpm_limit": null,
  "guardrails": null,
  "policies": null,
  "prompts": null,
  "blocked": null,
  "aliases": {},
  "object_permission": null,
  "key": "<redacted>",
  "tpd_limit": null,
  "default_estimated_output_tokens": null,
  "default_estimated_output_tokens_per_model": null,
  "budget_id": null,
  "end_user_budget_id": null,
  "tags": null,
  "disable_global_guardrails": null,
  "enable_prompt_caching": null,
  "throttle_on_budget_exceeded": null,
  "enforced_params": null,
  "allowed_routes": [],
  "allowed_passthrough_routes": null,
  "allowed_vector_store_indexes": null,
  "rpm_limit_type": null,
  "tpm_limit_type": null,
  "router_settings": {
    "routing_strategy_args": null,
    "routing_strategy": null,
    "routing_groups": null,
    "retry_policy": null,
    "model_group_retry_policy": null,
    "model_group_affinity_config": null,
    "allowed_fails": null,
    "cooldown_time": null,
    "num_retries": null,
    "timeout": null,
    "max_retries": null,
    "retry_after": null,
    "fallbacks": null,
    "context_window_fallbacks": null,
    "model_group_alias": {},
    "enable_tag_filtering": null,
    "weights": null,
    "tag_routing_prefix": null,
    "optional_pre_call_checks": null
  },
  "access_group_ids": [],
  "key_name": "<redacted-key-suffix>",
  "key_type": "default",
  "expires": null,
  "token_id": "<redacted>",
  "organization_id": null,
  "project_id": null,
  "litellm_budget_table": null,
  "token": "<redacted>",
  "created_by": "default_user_id",
  "updated_by": "default_user_id",
  "created_at": "2026-09-18T22:26:07.658000Z",
  "updated_at": "2026-09-18T22:26:07.658000Z"
}
```

## completion

```bash
curl -sS 'http://127.0.0.1:8192/v1/chat/completions' -H 'Authorization: Bearer $QA_KEY' -H 'Content-Type: application/json' --data-binary '{"model": "jev-live", "messages": [{"role": "user", "content": "What is the capital of Japan?"}], "max_tokens": 24, "metadata": {"session_id": "jev-proof-completion"}}'
```

HTTP 400

```json
{
  "error": {
    "message": "litellm.BadRequestError: You passed in model=jev-live. There are no healthy deployments for this model. Received Model Group=jev-live\nAvailable Model Group Fallbacks=None",
    "type": "invalid_request_error",
    "param": null,
    "code": "400"
  }
}
```

## routing-preview

```bash
curl -sS 'http://127.0.0.1:8192/auto_router/test_routing' -H 'Authorization: Bearer $QA_KEY' -H 'Content-Type: application/json' --data-binary '{"prompt": "Prove that the square root of two is irrational", "complexity_router_config": {"classifier_type": "jev", "tiers": {"SIMPLE": ["target-simple"], "MEDIUM": ["target-medium"], "COMPLEX": ["target-complex"], "REASONING": ["target-reasoning"]}, "classifier_fallback": "default_model", "fallback_tier": "REASONING", "jev_classifier_config": {"model": "jev-1.13.0", "timeout_ms": 10000, "circuit_breaker_enabled": false}}}'
```

HTTP 422

```json
{
  "detail": [
    {
      "type": "value_error",
      "loc": [
        "body",
        "complexity_router_config"
      ],
      "msg": "Value error, fallback_tier requires tier_definitions",
      "input": {
        "classifier_type": "jev",
        "tiers": {
          "SIMPLE": [
            "target-simple"
          ],
          "MEDIUM": [
            "target-medium"
          ],
          "COMPLEX": [
            "target-complex"
          ],
          "REASONING": [
            "target-reasoning"
          ]
        },
        "classifier_fallback": "default_model",
        "fallback_tier": "REASONING",
        "jev_classifier_config": {
          "model": "jev-1.13.0",
          "timeout_ms": 10000,
          "circuit_breaker_enabled": false
        }
      },
      "ctx": {
        "error": {}
      }
    }
  ]
}
```

## timeout-completion

```bash
curl -sS 'http://127.0.0.1:8192/v1/chat/completions' -H 'Authorization: Bearer $QA_KEY' -H 'Content-Type: application/json' --data-binary '{"model": "jev-timeout", "messages": [{"role": "user", "content": "Reply with the word ready"}], "max_tokens": 24, "metadata": {"session_id": "jev-proof-timeout"}}'
```

HTTP 400

```json
{
  "error": {
    "message": "litellm.BadRequestError: You passed in model=jev-timeout. There are no healthy deployments for this model. Received Model Group=jev-timeout\nAvailable Model Group Fallbacks=None",
    "type": "invalid_request_error",
    "param": null,
    "code": "400"
  }
}
```

## zero-key

```bash
curl -sS 'http://127.0.0.1:8192/key/generate' -H 'Authorization: Bearer $QA_KEY' -H 'Content-Type: application/json' --data-binary '{"user_id": "jev-benchmark-admin", "key_alias": "jev-benchmark-zero", "max_budget": 0}'
```

HTTP 200

```json
{
  "key_alias": "jev-benchmark-zero",
  "duration": null,
  "models": [],
  "spend": 0.0,
  "max_budget": 0.0,
  "user_id": "jev-benchmark-admin",
  "team_id": null,
  "agent_id": null,
  "max_parallel_requests": null,
  "metadata": {},
  "tpm_limit": null,
  "rpm_limit": null,
  "budget_duration": null,
  "budget_limits": null,
  "allowed_cache_controls": [],
  "config": {},
  "permissions": {},
  "model_max_budget": {},
  "budget_fallbacks": {},
  "model_rpm_limit": null,
  "model_tpm_limit": null,
  "mcp_rpm_limit": null,
  "tag_rpm_limit": null,
  "guardrails": null,
  "policies": null,
  "prompts": null,
  "blocked": null,
  "aliases": {},
  "object_permission": null,
  "key": "<redacted>",
  "tpd_limit": null,
  "default_estimated_output_tokens": null,
  "default_estimated_output_tokens_per_model": null,
  "budget_id": null,
  "end_user_budget_id": null,
  "tags": null,
  "disable_global_guardrails": null,
  "enable_prompt_caching": null,
  "throttle_on_budget_exceeded": null,
  "enforced_params": null,
  "allowed_routes": [],
  "allowed_passthrough_routes": null,
  "allowed_vector_store_indexes": null,
  "rpm_limit_type": null,
  "tpm_limit_type": null,
  "router_settings": {
    "routing_strategy_args": null,
    "routing_strategy": null,
    "routing_groups": null,
    "retry_policy": null,
    "model_group_retry_policy": null,
    "model_group_affinity_config": null,
    "allowed_fails": null,
    "cooldown_time": null,
    "num_retries": null,
    "timeout": null,
    "max_retries": null,
    "retry_after": null,
    "fallbacks": null,
    "context_window_fallbacks": null,
    "model_group_alias": {},
    "enable_tag_filtering": null,
    "weights": null,
    "tag_routing_prefix": null,
    "optional_pre_call_checks": null
  },
  "access_group_ids": [],
  "key_name": "<redacted-key-suffix>",
  "key_type": "default",
  "expires": null,
  "token_id": "<redacted>",
  "organization_id": null,
  "project_id": null,
  "litellm_budget_table": null,
  "token": "<redacted>",
  "created_by": "default_user_id",
  "updated_by": "default_user_id",
  "created_at": "2026-09-18T22:26:07.736000Z",
  "updated_at": "2026-09-18T22:26:07.736000Z"
}
```

## zero-budget-preview

```bash
curl -sS 'http://127.0.0.1:8192/auto_router/test_routing' -H 'Authorization: Bearer $QA_KEY' -H 'Content-Type: application/json' --data-binary '{"prompt": "What is 2 plus 2?", "complexity_router_config": {"classifier_type": "jev", "tiers": {"SIMPLE": ["target-simple"], "MEDIUM": ["target-medium"], "COMPLEX": ["target-complex"], "REASONING": ["target-reasoning"]}, "classifier_fallback": "default_model", "fallback_tier": "REASONING", "jev_classifier_config": {"model": "jev-1.13.0", "timeout_ms": 10000, "circuit_breaker_enabled": false}}}'
```

HTTP 422

```json
{
  "detail": [
    {
      "type": "value_error",
      "loc": [
        "body",
        "complexity_router_config"
      ],
      "msg": "Value error, fallback_tier requires tier_definitions",
      "input": {
        "classifier_type": "jev",
        "tiers": {
          "SIMPLE": [
            "target-simple"
          ],
          "MEDIUM": [
            "target-medium"
          ],
          "COMPLEX": [
            "target-complex"
          ],
          "REASONING": [
            "target-reasoning"
          ]
        },
        "classifier_fallback": "default_model",
        "fallback_tier": "REASONING",
        "jev_classifier_config": {
          "model": "jev-1.13.0",
          "timeout_ms": 10000,
          "circuit_breaker_enabled": false
        }
      },
      "ctx": {
        "error": {}
      }
    }
  ]
}
```

import asyncio
import hashlib
import json
import os
import random
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Final, Literal

import httpx
import litellm
import uvicorn
from fastapi import FastAPI, Request, Response
from litellm import Router
from litellm.router_strategy.complexity_router.complexity_router import ComplexityRouter
from pydantic import BaseModel, TypeAdapter

ROOT: Final = Path(__file__).resolve().parent
REPO: Final = Path(os.environ.get("BENCHMARK_REPO", "/home/ubuntu/jev-rehearsal"))
MAPPING: Final = TypeAdapter(dict[str, object])
STRINGS: Final = TypeAdapter(dict[str, str])
PORT: Final = 8191


class Case(BaseModel):
    id: str
    label: str
    tags: str
    prompt: str
    messages: tuple[dict[str, str], ...]
    rationale: str


class Protocol(BaseModel):
    rubric: dict[str, str]
    instructions: str
    concurrency: int
    repeats: int
    warmup_pairs: int
    seed: int
    timeout_ms: int
    fallback_tier: str
    context_window_size: int
    context_budget_chars: int
    context_per_turn_chars: int
    include_assistant_turns: bool
    llm_model: str


def append(name: str, value: object) -> None:
    with (ROOT / name).open("a") as output:
        output.write(json.dumps(value, sort_keys=True) + "\n")


class Relay:
    def __init__(self, client: httpx.AsyncClient) -> None:
        self.client = client
        self.attempt = "initialization"
        self.app = FastAPI()
        self.app.add_api_route("/{provider}/{path:path}", self.forward, methods=["POST"])

    async def forward(self, provider: str, path: str, request: Request) -> Response:
        attempt: Final = self.attempt
        origin: Final = {
            "jev": ("https://api.typesafe.ai", {"Authorization": f"Bearer {os.environ['TYPESAFE_API_KEY']}"}),
            "anthropic": ("https://api.anthropic.com", {"x-api-key": os.environ["ANTHROPIC_API_KEY"]}),
        }
        if provider not in origin:
            return Response(status_code=404)
        base, auth = origin[provider]
        body: Final = await request.body()
        started: Final = time.perf_counter()
        append(
            "wire.jsonl",
            {
                "attempt": attempt,
                "event": "request",
                "provider": provider,
                "path": path,
                "utc": datetime.now(timezone.utc).isoformat(),
                "body": MAPPING.validate_json(body),
            },
        )
        try:
            result: Final = await self.client.post(
                f"{base}/{path}",
                content=body,
                timeout=10,
                headers={
                    **auth,
                    "content-type": "application/json",
                    **{k: v for k, v in request.headers.items() if k.startswith("anthropic-")},
                },
            )
        except httpx.HTTPError as error:
            append(
                "wire.jsonl",
                {
                    "attempt": attempt,
                    "event": "error",
                    "error_type": type(error).__name__,
                    "upstream_elapsed_ms": 1000 * (time.perf_counter() - started),
                },
            )
            return Response(content='{"error":{"type":"relay_upstream_error"}}', status_code=504)
        response_body: Final = MAPPING.validate_json(result.content)
        safe_body: Final = {
            k: v
            for k, v in response_body.items()
            if k in {"model", "usage", "answers", "content", "stop_reason", "type"}
        }
        append(
            "wire.jsonl",
            {
                "attempt": attempt,
                "event": "response",
                "status": result.status_code,
                "body": safe_body,
                "upstream_elapsed_ms": 1000 * (time.perf_counter() - started),
            },
        )
        return Response(content=result.content, status_code=result.status_code, media_type="application/json")


def config(protocol: Protocol, engine: Literal["jev", "llm"], version: str) -> dict[str, object]:
    shared: Final = {
        "classifier_type": engine,
        "tiers": {tier: ["downstream"] for tier in protocol.rubric},
        "tier_definitions": [{"name": tier, "description": text} for tier, text in protocol.rubric.items()],
        "fallback_tier": protocol.fallback_tier,
        "classifier_context_window_size": protocol.context_window_size,
        "classifier_context_budget_chars": protocol.context_budget_chars,
        "classifier_context_per_turn_chars": protocol.context_per_turn_chars,
        "classifier_context_include_assistant_turns": protocol.include_assistant_turns,
    }
    classifier: Final = (
        {
            "jev_classifier_config": {
                "model": version,
                "api_base": f"http://127.0.0.1:{PORT}/jev",
                "api_key": os.environ["TYPESAFE_API_KEY"],
                "instructions": protocol.instructions,
                "timeout_ms": protocol.timeout_ms,
                "circuit_breaker_enabled": False,
            }
        }
        if engine == "jev"
        else {
            "classification_prompt": protocol.instructions,
            "classifier_llm_config": {
                "model": "classifier",
                "timeout_ms": protocol.timeout_ms,
                "circuit_breaker_enabled": False,
            },
        }
    )
    return {**shared, **classifier}


async def attempt(
    relay: Relay, router: ComplexityRouter, case: Case, engine: str, attempt_id: str, repeat: int, warmup: bool
) -> dict[str, object]:
    relay.attempt = attempt_id
    started_utc: Final = datetime.now(timezone.utc).isoformat()
    started: Final = time.perf_counter()
    outcome: Final = await router.aclassify(
        case.prompt, messages=case.messages, request_kwargs={"turn_off_message_logging": True}
    )
    elapsed: Final = 1000 * (time.perf_counter() - started)
    row: Final = {
        "attempt": attempt_id,
        "case_id": case.id,
        "expected": case.label,
        "tags": case.tags,
        "engine": engine,
        "repeat": repeat,
        "warmup": warmup,
        "started_utc": started_utc,
        "elapsed_ms": elapsed,
        "tier": str(outcome.tier),
        "cause": outcome.cause,
        "signals": outcome.signals,
        "classifier_cost": outcome.classifier_cost,
        "resolved_jev_model": outcome.jev_verdict.model if outcome.jev_verdict is not None else None,
    }
    append("attempts.jsonl", row)
    print(json.dumps({k: row[k] for k in ("attempt", "tier", "cause", "elapsed_ms")}), flush=True)
    return row


async def main() -> None:
    frozen: Final = MAPPING.validate_json((ROOT / "freeze.json").read_bytes())
    assert hashlib.sha256((ROOT / "cases.jsonl").read_bytes()).hexdigest() == frozen["corpus_sha256"]
    assert hashlib.sha256((ROOT / "protocol.json").read_bytes()).hexdigest() == frozen["protocol_sha256"]
    if (ROOT / "attempts.jsonl").exists():
        raise RuntimeError("Use a fresh output directory for each full benchmark; no overwriting attempts")
    protocol: Final = Protocol.model_validate_json((ROOT / "protocol.json").read_bytes())
    cases: Final = tuple(Case.model_validate_json(line) for line in (ROOT / "cases.jsonl").read_text().splitlines())
    litellm.cache = None
    litellm.suppress_debug_info = True
    registry: Final = (REPO / "model_prices_and_context_window.json").read_bytes()
    (ROOT / "registry.json").write_bytes(registry)
    (ROOT / "provenance.json").write_text(
        json.dumps(
            {
                "code_sha": subprocess.check_output(["git", "-C", str(REPO), "rev-parse", "HEAD"], text=True).strip(),
                "tree_sha": subprocess.check_output(
                    ["git", "-C", str(REPO), "rev-parse", "HEAD^{tree}"], text=True
                ).strip(),
                "registry_sha256": hashlib.sha256(registry).hexdigest(),
                "budget_sha": "b9e5bb3abb0f2f0ddc06dcaf9edb63563cac2a2a",
                "feature_sha": "8e5f43f45897fc72612aac53a690fa573ce029cd",
                "main_sha": "1d91fc232d20a434a86323506a1303935b9c684f",
                "regions": "Client VM region and provider serving regions unknown",
                "instrumentation": (
                    "Symmetric loopback HTTP relay captures requests/responses; production aclassify timed"
                ),
            },
            indent=2,
        )
        + "\n"
    )
    router: Final = Router(
        model_list=[
            {
                "model_name": "classifier",
                "litellm_params": {
                    "model": protocol.llm_model,
                    "api_key": os.environ["ANTHROPIC_API_KEY"],
                    "api_base": f"http://127.0.0.1:{PORT}/anthropic",
                },
            },
            {
                "model_name": "downstream",
                "litellm_params": {"model": protocol.llm_model, "api_key": os.environ["ANTHROPIC_API_KEY"]},
            },
        ],
        num_retries=0,
        cache_responses=False,
    )
    async with httpx.AsyncClient() as client:
        relay: Final = Relay(client)
        server: Final = uvicorn.Server(uvicorn.Config(relay.app, host="127.0.0.1", port=PORT, log_level="error"))
        server_task: Final = asyncio.create_task(server.serve())
        async with httpx.AsyncClient() as local:
            for _ in range(100):
                try:
                    await local.get(f"http://127.0.0.1:{PORT}/openapi.json")
                    break
                except httpx.ConnectError:
                    await asyncio.sleep(0.05)
        resolver: Final = ComplexityRouter("resolve", router, config(protocol, "jev", "jev-latest"))
        resolution: Final = await attempt(relay, resolver, cases[0], "jev", "resolution", -1, True)
        version: Final = resolution["resolved_jev_model"]
        if not isinstance(version, str) or version == "jev-latest":
            raise RuntimeError("JEV alias did not resolve to a version")
        classifiers: Final = {
            engine: ComplexityRouter(engine, router, config(protocol, engine, version)) for engine in ("jev", "llm")
        }
        (ROOT / "models.json").write_text(
            json.dumps(
                {
                    "jev_alias": "jev-latest",
                    "jev_resolved": version,
                    "llm_requested": protocol.llm_model,
                },
                indent=2,
            )
            + "\n"
        )
        for index, case in enumerate((cases[0], cases[20], cases[40], cases[60])):
            for engine in ("jev", "llm") if index % 2 == 0 else ("llm", "jev"):
                await attempt(relay, classifiers[engine], case, engine, f"warmup-{index}-{engine}", -1, True)
        for repeat, ordered in (
            (repeat, random.Random(protocol.seed + repeat).sample(cases, len(cases)))
            for repeat in range(protocol.repeats)
        ):
            for index, case in enumerate(ordered):
                for engine in ("jev", "llm") if (repeat * len(cases) + index) % 2 == 0 else ("llm", "jev"):
                    await attempt(
                        relay,
                        classifiers[engine],
                        case,
                        engine,
                        f"r{repeat}-{case.id}-{engine}",
                        repeat,
                        False,
                    )
        server.should_exit = True
        await server_task


if __name__ == "__main__":
    asyncio.run(main())

import asyncio
import hashlib
import json
import os
import re
import secrets
import subprocess
import sys
from pathlib import Path
from typing import Final

import httpx
from pydantic import TypeAdapter

ROOT: Final = Path(__file__).resolve().parent
REPO: Final = Path(os.environ.get("BENCHMARK_REPO", "/home/ubuntu/jev-rehearsal"))
PYTHON: Final = sys.executable
BASE: Final = "http://127.0.0.1:8192"
OBJECT: Final = TypeAdapter(dict[str, object])
STRINGS: Final = TypeAdapter(dict[str, str])
DATABASE: Final = "postgresql://ubuntu@localhost/jev_benchmark_final?host=/var/run/postgresql"


def write(name: str, value: object) -> None:
    (ROOT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


def sql(query: str) -> object:
    result: Final = subprocess.check_output(
        ["psql", DATABASE, "-X", "-A", "-t", "-v", "ON_ERROR_STOP=1", "-c", query], text=True
    )
    return json.loads(result)


class Evidence:
    def __init__(self, master: str) -> None:
        self.secret_values = [
            master,
            os.environ["TYPESAFE_API_KEY"],
            os.environ["ANTHROPIC_API_KEY"],
            os.environ.get("OP_SERVICE_ACCOUNT_TOKEN", ""),
        ]

    def redact(self, text: str) -> str:
        result = text
        for secret in self.secret_values:
            if secret:
                result = result.replace(secret, "<redacted>")
        return re.sub(r"sk-\.\.\.[A-Za-z0-9_-]+", "<redacted-key-suffix>", result)

    async def request(self, name: str, path: str, body: dict[str, object], key: str) -> dict[str, object]:
        process: Final = await asyncio.create_subprocess_exec(
            "curl",
            "--silent",
            "--show-error",
            "--max-time",
            "40",
            "--config",
            "-",
            "--header",
            "Content-Type: application/json",
            "--data-binary",
            json.dumps(body),
            "--write-out",
            "\n%{http_code}",
            BASE + path,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, stderr = await process.communicate(f'header = "Authorization: Bearer {key}"\n'.encode())
        if process.returncode:
            raise RuntimeError(self.redact(stderr.decode()))
        text, status = stdout.decode().rsplit("\n", 1)
        result: Final = OBJECT.validate_json(text)
        for field in ("key", "token"):
            value = result.get(field)
            if isinstance(value, str):
                self.secret_values.append(value)
        safe_result: Final = json.loads(self.redact(json.dumps(result)))
        write(f"gateway-{name}.json", {"status": int(status), "body": safe_result})
        with (ROOT / "curl-evidence.md").open("a") as output:
            output.write(
                f"\n## {name}\n\n```bash\n"
                f"curl -sS '{BASE}{path}' -H 'Authorization: Bearer $QA_KEY' "
                "-H 'Content-Type: application/json' "
                f"--data-binary '{json.dumps(body)}'\n```\n\n"
                f"HTTP {status}\n\n```json\n{json.dumps(safe_result, indent=2)}\n```\n"
            )
        print(f"{name}: HTTP {status}", flush=True)
        return result

    async def log(self, stream: asyncio.StreamReader) -> None:
        with (ROOT / "gateway-server.log").open("w") as output:
            while line := await stream.readline():
                output.write(self.redact(line.decode(errors="replace")))
                output.flush()


def router_config(version: str, timeout_ms: int) -> dict[str, object]:
    return {
        "classifier_type": "jev",
        "tiers": {tier: [f"target-{tier.lower()}"] for tier in ("SIMPLE", "MEDIUM", "COMPLEX", "REASONING")},
        "classifier_fallback": "default_model",
        "jev_classifier_config": {"model": version, "timeout_ms": timeout_ms, "circuit_breaker_enabled": False},
    }


async def main() -> None:
    master: Final = "sk-" + secrets.token_urlsafe(32)
    evidence: Final = Evidence(master)
    models: Final = STRINGS.validate_json((ROOT / "models.json").read_bytes())
    configuration: Final = {
        "model_list": [
            *(
                {
                    "model_name": f"target-{tier}",
                    "litellm_params": {
                        "model": models["llm_requested"],
                        "api_key": "os.environ/ANTHROPIC_API_KEY",
                    },
                }
                for tier in ("simple", "medium", "complex", "reasoning")
            ),
            *(
                {
                    "model_name": name,
                    "litellm_params": {
                        "model": "auto_router/complexity_router",
                        "complexity_router_default_model": "target-reasoning",
                        "complexity_router_config": router_config(models["jev_resolved"], timeout_ms),
                    },
                }
                for name, timeout_ms in (("jev-live", 10000), ("jev-timeout", 1))
            ),
        ],
        "general_settings": {
            "master_key": "os.environ/LITELLM_MASTER_KEY",
            "database_url": "os.environ/DATABASE_URL",
            "proxy_batch_write_at": 1,
            "disable_spend_logs": False,
        },
        "litellm_settings": {"set_verbose": False, "turn_off_message_logging": True},
        "router_settings": {"num_retries": 0},
    }
    write("gateway-config.json", configuration)
    environment: Final = {
        **os.environ,
        "DATABASE_URL": DATABASE,
        "LITELLM_MASTER_KEY": master,
        "PYTHONPATH": f"{REPO}:{REPO / 'enterprise'}",
        "LITELLM_LOCAL_MODEL_COST_MAP": "True",
        "DISABLE_SCHEMA_UPDATE": "true",
        "LITELLM_LOG": "ERROR",
    }
    server: Final = await asyncio.create_subprocess_exec(
        PYTHON,
        str(REPO / "litellm/proxy/proxy_cli.py"),
        "--config",
        str(ROOT / "gateway-config.json"),
        "--host",
        "127.0.0.1",
        "--port",
        "8192",
        env=environment,
        cwd=REPO,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.STDOUT,
    )
    assert server.stdout is not None
    logging: Final = asyncio.create_task(evidence.log(server.stdout))
    try:
        async with httpx.AsyncClient() as client:
            for _ in range(120):
                if server.returncode is not None:
                    raise RuntimeError("Gateway exited; inspect sanitized gateway-server.log")
                try:
                    health = await client.get(BASE + "/health/liveliness", timeout=2)
                    if health.status_code == 200:
                        break
                except httpx.HTTPError:
                    pass
                await asyncio.sleep(0.5)
            else:
                raise RuntimeError("Gateway not ready")
        user: Final = await evidence.request(
            "user",
            "/user/new",
            {
                "user_id": "jev-benchmark-admin",
                "user_role": "proxy_admin",
                "auto_create_key": False,
            },
            master,
        )
        assert user.get("user_id") == "jev-benchmark-admin"
        funded: Final = await evidence.request(
            "funded-key",
            "/key/generate",
            {
                "user_id": "jev-benchmark-admin",
                "key_alias": "jev-benchmark-funded",
                "max_budget": 1,
            },
            master,
        )
        key: Final = funded["key"]
        assert isinstance(key, str)
        key_hash: Final = hashlib.sha256(key.encode()).hexdigest()
        await evidence.request(
            "completion",
            "/v1/chat/completions",
            {
                "model": "jev-live",
                "messages": [{"role": "user", "content": "What is the capital of Japan?"}],
                "max_tokens": 24,
                "metadata": {"session_id": "jev-proof-completion"},
            },
            key,
        )
        await evidence.request(
            "routing-preview",
            "/auto_router/test_routing",
            {
                "prompt": "Prove that the square root of two is irrational",
                "default_model": "target-reasoning",
                "complexity_router_config": router_config(models["jev_resolved"], 10000),
            },
            key,
        )
        await evidence.request(
            "timeout-completion",
            "/v1/chat/completions",
            {
                "model": "jev-timeout",
                "messages": [{"role": "user", "content": "Reply with the word ready"}],
                "max_tokens": 24,
                "metadata": {"session_id": "jev-proof-timeout"},
            },
            key,
        )
        zero: Final = await evidence.request(
            "zero-key",
            "/key/generate",
            {
                "user_id": "jev-benchmark-admin",
                "key_alias": "jev-benchmark-zero",
                "max_budget": 0,
            },
            master,
        )
        zero_key: Final = zero["key"]
        assert isinstance(zero_key, str)
        await evidence.request(
            "zero-budget-preview",
            "/auto_router/test_routing",
            {
                "prompt": "What is 2 plus 2?",
                "default_model": "target-reasoning",
                "complexity_router_config": router_config(models["jev_resolved"], 10000),
            },
            zero_key,
        )
        await asyncio.sleep(20)
        rows: Final = sql("""
            SELECT coalesce(json_agg(x), '[]'::json) FROM (
                SELECT request_id,call_type,spend,prompt_tokens,completion_tokens,model,model_group,
                       custom_llm_provider,session_id,status,
                       metadata->'routing_decision' AS routing_decision,
                       metadata->'internal_call_origin' AS internal_call_origin,
                       "user" AS user_id
                FROM "LiteLLM_SpendLogs" ORDER BY "startTime",request_id
            ) x
        """)
        key_spend: Final = sql(f"""
            SELECT row_to_json(x) FROM (
                SELECT key_alias,spend,total_spend,max_budget,
                  (SELECT sum(spend) FROM "LiteLLM_SpendLogs" WHERE api_key='{key_hash}') AS spend_row_sum,
                  (SELECT count(*) FROM "LiteLLM_SpendLogs" WHERE api_key='{key_hash}') AS attributed_row_count
                FROM "LiteLLM_VerificationToken" WHERE token='{key_hash}'
            ) x
        """)
        write("gateway-spend-rows.json", rows)
        write("gateway-key-spend.json", key_spend)
        write(
            "gateway-database.json",
            {"database": "jev_benchmark_final", "schema_source": str(REPO / "schema.prisma")},
        )
        print("Gateway persisted spend evidence collected", flush=True)
    finally:
        server.terminate()
        await server.wait()
        await logging


if __name__ == "__main__":
    asyncio.run(main())

import hashlib
import json
import math
import random
import statistics
from collections import Counter
from pathlib import Path
from typing import Final

from pydantic import BaseModel, TypeAdapter

ROOT: Final = Path(__file__).resolve().parent
TIERS: Final = ("SIMPLE", "MEDIUM", "COMPLEX", "REASONING")
ENGINES: Final = ("jev", "llm")


class Attempt(BaseModel):
    attempt: str
    case_id: str
    engine: str
    repeat: int
    expected: str
    tier: str
    elapsed_ms: float
    classifier_cost: float | None
    cause: str
    warmup: bool
    tags: str


class Usage(BaseModel):
    input_tokens: int
    output_tokens: int
    cache_read_input_tokens: int = 0
    cache_creation_input_tokens: int = 0
    inference_geo: str | None = None


class Body(BaseModel):
    model: str
    usage: Usage


class Wire(BaseModel):
    attempt: str
    event: str
    body: dict[str, object] | None = None
    status: int | None = None
    error_type: str | None = None


class Price(BaseModel):
    input_cost_per_token: float
    output_cost_per_token: float


def quantile(values: tuple[float, ...], q: float) -> float:
    ordered: Final = sorted(values)
    index: Final = (len(ordered) - 1) * q
    low: Final = math.floor(index)
    high: Final = math.ceil(index)
    return ordered[low] + (ordered[high] - ordered[low]) * (index - low)


def metric(rows: tuple[Attempt, ...]) -> dict[str, float]:
    jev, llm = (tuple(row for row in rows if row.engine == engine) for engine in ENGINES)
    jm, lm = (statistics.fmean(row.elapsed_ms for row in engine_rows) for engine_rows in (jev, llm))
    j50, l50 = (quantile(tuple(row.elapsed_ms for row in engine_rows), 0.5) for engine_rows in (jev, llm))
    j95, l95 = (quantile(tuple(row.elapsed_ms for row in engine_rows), 0.95) for engine_rows in (jev, llm))
    ja, la = (100 * statistics.fmean(row.expected == row.tier for row in engine_rows) for engine_rows in (jev, llm))
    jc, lc = (statistics.fmean(row.classifier_cost or 0 for row in engine_rows) for engine_rows in (jev, llm))
    paired: Final = {(row.case_id, row.repeat): row.tier for row in llm}
    return {
        "jev_accuracy_pct": ja,
        "llm_accuracy_pct": la,
        "accuracy_difference_pp": ja - la,
        "agreement_pct": 100 * statistics.fmean(row.tier == paired[row.case_id, row.repeat] for row in jev),
        "jev_mean_ms": jm,
        "llm_mean_ms": lm,
        "mean_speedup_pct": 100 * (lm / jm - 1),
        "mean_latency_reduction_pct": 100 * (1 - jm / lm),
        "jev_p50_ms": j50,
        "llm_p50_ms": l50,
        "p50_speedup_pct": 100 * (l50 / j50 - 1),
        "p50_latency_reduction_pct": 100 * (1 - j50 / l50),
        "jev_p95_ms": j95,
        "llm_p95_ms": l95,
        "p95_speedup_pct": 100 * (l95 / j95 - 1),
        "p95_latency_reduction_pct": 100 * (1 - j95 / l95),
        "jev_mean_cost_usd": jc,
        "llm_mean_cost_usd": lc,
        "cost_savings_pct": 100 * (1 - jc / lc),
    }


def bootstrap(rows: tuple[Attempt, ...]) -> dict[str, object]:
    ids: Final = tuple(sorted({row.case_id for row in rows}))
    clusters: Final = {case_id: tuple(row for row in rows if row.case_id == case_id) for case_id in ids}
    rng: Final = random.Random(20260918)
    samples: Final = tuple(
        metric(tuple(row for case_id in rng.choices(ids, k=len(ids)) for row in clusters[case_id]))
        for _ in range(10000)
    )
    observed: Final = metric(rows)
    return {
        name: {
            "estimate": value,
            "ci95": [
                quantile(tuple(sample[name] for sample in samples), 0.025),
                quantile(tuple(sample[name] for sample in samples), 0.975),
            ],
        }
        for name, value in observed.items()
    }


def main() -> None:
    freeze: Final = TypeAdapter(dict[str, object]).validate_json((ROOT / "freeze.json").read_bytes())
    assert hashlib.sha256((ROOT / "cases.jsonl").read_bytes()).hexdigest() == freeze["corpus_sha256"]
    assert hashlib.sha256((ROOT / "protocol.json").read_bytes()).hexdigest() == freeze["protocol_sha256"]
    all_rows: Final = tuple(
        Attempt.model_validate_json(line) for line in (ROOT / "attempts.jsonl").read_text().splitlines()
    )
    rows: Final = tuple(row for row in all_rows if not row.warmup)
    assert len(rows) == 480
    assert len({row.attempt for row in rows}) == len(rows)
    assert Counter((row.engine, row.expected) for row in rows) == {
        (engine, tier): 60 for engine in ENGINES for tier in TIERS
    }
    assert all(
        sorted(row.repeat for row in rows if row.case_id == case_id and row.engine == engine) == [0, 1, 2]
        for case_id in {row.case_id for row in rows}
        for engine in ENGINES
    )
    wire: Final = tuple(Wire.model_validate_json(line) for line in (ROOT / "wire.jsonl").read_text().splitlines())
    measured: Final = frozenset(row.attempt for row in rows)
    requests: Final = tuple(event for event in wire if event.attempt in measured and event.event == "request")
    responses: Final = {event.attempt: event for event in wire if event.event == "response"}
    assert Counter(event.attempt for event in requests) == Counter(row.attempt for row in rows)
    prices: Final = TypeAdapter(dict[str, object]).validate_json((ROOT / "registry.json").read_bytes())
    price_models: Final = {"jev": "typesafe/jev-1.13.0", "llm": "claude-haiku-4-5-20251001"}
    resolved_prices: Final = {engine: Price.model_validate(prices[model]) for engine, model in price_models.items()}
    priced: Final = tuple(
        (row, Body.model_validate(responses[row.attempt].body), resolved_prices[row.engine])
        for row in rows
        if row.attempt in responses and responses[row.attempt].status == 200
    )
    assert len(priced) == 480
    assert all(
        math.isclose(
            row.classifier_cost or 0,
            body.usage.input_tokens * price.input_cost_per_token
            + body.usage.output_tokens * price.output_cost_per_token,
            rel_tol=1e-9,
            abs_tol=1e-12,
        )
        for row, body, price in priced
    )
    summaries: Final = {
        engine: {
            "attempts": sum(row.engine == engine for row in rows),
            "correct": sum(row.engine == engine and row.expected == row.tier for row in rows),
            "causes": dict(Counter(row.cause for row in rows if row.engine == engine)),
            "failures_or_fallbacks": sum(row.engine == engine and row.cause != f"{engine}_classifier" for row in rows),
            "provider_errors": sum(
                event.attempt in measured and event.event == "error" and event.attempt.endswith(f"-{engine}")
                for event in wire
            ),
            "http_statuses": dict(
                Counter(
                    event.status
                    for event in responses.values()
                    if event.attempt in measured and event.attempt.endswith(f"-{engine}")
                )
            ),
            "resolved_models": sorted({body.model for row, body, _ in priced if row.engine == engine}),
            "input_tokens": sum(body.usage.input_tokens for row, body, _ in priced if row.engine == engine),
            "output_tokens": sum(body.usage.output_tokens for row, body, _ in priced if row.engine == engine),
            "cache_read_input_tokens": sum(
                body.usage.cache_read_input_tokens for row, body, _ in priced if row.engine == engine
            ),
            "cache_creation_input_tokens": sum(
                body.usage.cache_creation_input_tokens for row, body, _ in priced if row.engine == engine
            ),
            "total_cost_usd": sum(row.classifier_cost or 0 for row in rows if row.engine == engine),
            "successful_p50_ms": quantile(
                tuple(row.elapsed_ms for row in rows if row.engine == engine and row.cause == f"{engine}_classifier"),
                0.5,
            ),
            "successful_p95_ms": quantile(
                tuple(row.elapsed_ms for row in rows if row.engine == engine and row.cause == f"{engine}_classifier"),
                0.95,
            ),
            "confusion_matrix": {
                label: dict(Counter(row.tier for row in rows if row.engine == engine and row.expected == label))
                for label in TIERS
            },
            "registry_price_model": price_models[engine],
            "registry_price_per_token_usd": resolved_prices[engine].model_dump(),
        }
        for engine in ENGINES
    }
    print("Validated all 480 attempts and independent usage repricing; bootstrapping", flush=True)
    output: Final = {
        "engines": summaries,
        "overall": bootstrap(rows),
        "per_tier": {tier: bootstrap(tuple(row for row in rows if row.expected == tier)) for tier in TIERS},
        "boundary_subset": bootstrap(tuple(row for row in rows if "boundary" in row.tags)),
        "by_tag": {
            tag: metric(tuple(row for row in rows if tag in row.tags))
            for tag in ("short", "long", "followup", "tool", "boundary")
        },
        "by_repeat": {str(repeat): metric(tuple(row for row in rows if row.repeat == repeat)) for repeat in range(3)},
        "mismatches": [row.model_dump() for row in rows if row.tier != row.expected],
        "uncertainty": {
            "method": "percentile bootstrap, resample case clusters retaining both classifiers and all three repeats",
            "samples": 10000,
            "seed": 20260918,
            "confidence": 0.95,
            "quantile": "linear interpolation",
            "caution": "80 authored cases, not 240 independent quality observations; no generalization guarantee",
        },
    }
    (ROOT / "metrics.json").write_text(json.dumps(output, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"engines": summaries, "overall": output["overall"]}, indent=2))


if __name__ == "__main__":
    main()

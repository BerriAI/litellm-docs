# Live JEV and Haiku classifier benchmark

## Supported conclusion

On this frozen, authored 80-case synthetic corpus, the integrated JEV classifier was faster, cheaper at registry prices, and matched more authored labels than the existing LLM classifier configured with the same tier rubric and Claude Haiku 4.5

Across three paired repeats, JEV matched 228 of 240 labels, or 95.00%, versus Haiku's 177 of 240, or 73.75%. Median classifier latency was 126.81 ms versus 688.40 ms. The ratio of medians gives 442.84% speedup under the requested definition, equivalent to 81.58% latency reduction. Registry-priced classifier cost was $0.007706664 versus $0.198534 across 240 measured calls each, or 96.118% savings

These are classifier results on this corpus. They do not measure downstream answer quality, independent benchmark performance, production throughput, overall application latency, invoice amounts, or production-wide cost savings

## Provenance

| Field | Value |
| --- | --- |
| Benchmark date | 2026-09-18 UTC |
| Measured window | 22:21:05.811 through approximately 22:24:32 UTC |
| Cases frozen | 22:18:53.385676 UTC, before any provider requests |
| Current-main base | `1d91fc232d20a434a86323506a1303935b9c684f` |
| Budget tip, applied first | `b9e5bb3abb0f2f0ddc06dcaf9edb63563cac2a2a` |
| Feature tip, applied second | `8e5f43f45897fc72612aac53a690fa573ce029cd` |
| Local rehearsal commit | `28e3d5c89f85c09fd27b06a9abe1403679c06aa7` |
| Local rehearsal tree | `9dce43d6a0562a4926c39b1bacf7e9a1feac1170` |
| Corpus SHA256 | `dc85aa66fcab982a2af812a46c6bcd17e0e2a764c2e0c921fb811ce0ce4f31ce` |
| Protocol SHA256 | `27d564fa022d29d8d9dd9c1a905fbf9a92695a138271f59d1174e7b7c49c4927` |
| Registry SHA256 | `529638485889e5499ddb631f05a7fa58c7aaa25ebddfea8b5152d6eca77b1d2b` |
| JEV alias resolution | `jev-latest` returned `jev-1.13.0`, then all measured requests pinned `jev-1.13.0` |
| JEV API | `https://api.typesafe.ai/v1/systemone`, Choice question `tier` |
| LLM requested | `anthropic/claude-haiku-4-5-20251001` |
| LLM returned | `claude-haiku-4-5-20251001` on every measured response |
| Regions | Client VM location and provider serving regions unknown, Anthropic returned `inference_geo: not_available` |
| Related integration PR | https://github.com/BerriAI/litellm/pull/41886 |

The rehearsal and all measurements used the exact budget-first, feature-second combination. No production classifier source was changed. The local merge commit is not pushed, so reproducibility relies on the three input commits and the resulting tree hash. This report does not assert the PR's lifecycle or review status

## Dataset and protocol

The corpus contains 20 cases per SIMPLE, MEDIUM, COMPLEX and REASONING tier. It includes 40 short cases, 16 long cases, eight followups, eight cases with tool context and eight ambiguous boundary cases. Each case has an authored rationale. The exact rubric, classification instructions and context settings are in `protocol.json`, and the expanded prompts and prior turns are in `cases.jsonl`

SIMPLE covers lookup, elementary arithmetic and mechanical formatting. MEDIUM covers routine drafting, summaries, explanation and localized code. COMPLEX covers nontrivial code, coupled system design and multistep technical diagnosis. REASONING covers explicit proofs, optimization with justification and decisions with conflicting objectives or uncertainty

Both existing production classifier paths received the same authored rubric and opening instructions. JEV used `classifier_type: jev` and `jev_classifier_config`; the comparison used the existing `classifier_type: llm` structured-output path with a current small Haiku-family model in the checked-in registry. Wire templates differ by architecture, including the LLM trust boundary and structured-output wrapper. The benchmark did not replace either classifier implementation or independently tune either prompt

Each repeat used a seeded shuffled case order, with JEV-first and LLM-first alternating across consecutive pairs. Concurrency was one, with 10,000 ms deadlines, no retries, disabled circuit breakers and REASONING fallback. Context window was three turns, 8,000 total characters and 4,000 characters per turn, including assistant turns. Temperature and other sampling settings were left at the existing classifier defaults

One alias-resolution call and four warmup pairs were excluded from the corrected run's measured set. A prior setup attempt also made one successful alias-resolution call, then stopped on configuration validation before any measured calls. Both setup records are retained. The final measured set contains exactly 480 requests, 240 per classifier, with exactly three observations per case and classifier and no omitted measured attempts

LiteLLM response caching was disabled and no provider prompt-cache directives were sent. Haiku reported zero cache-read and zero cache-creation tokens for every measured request. JEV cache usage was not exposed. Internal provider caching and scheduling remain unknown

Latency is wall-clock time around the production `ComplexityRouter.aclassify` call. A symmetric local HTTP relay forwarded real provider requests and recorded allowlisted request and response fields without authorization headers. This includes client/network/provider time and local relay overhead, not gateway completion time. Gateway proof ran after the benchmark completed

## Latency and cost

Intervals below are 95% percentile bootstrap intervals from 10,000 resamples of case clusters, seed 20260918, retaining all three repeats and both classifiers within each selected case. Quantiles use linear interpolation. They capture variation within this small authored corpus and run, not deployment-wide uncertainty

| Metric | JEV estimate [95% interval] | Haiku estimate [95% interval] |
| --- | --- | --- |
| All-attempt mean latency, ms | 138.38 [131.87, 145.93] | 720.71 [702.48, 740.32] |
| All-attempt p50 latency, ms | 126.81 [121.42, 132.15] | 688.40 [677.76, 703.89] |
| All-attempt p95 latency, ms | 231.16 [204.28, 298.88] | 896.94 [814.91, 1024.82] |
| Successful-call p50 latency, ms | 126.81 [121.42, 132.15] | 688.40 [677.76, 703.89] |
| Successful-call p95 latency, ms | 231.16 [204.28, 298.88] | 896.94 [814.91, 1024.82] |
| Maximum measured latency, ms | 401.26 | 1,914.98 |
| Mean classifier cost, USD | 0.0000321111 [0.0000272217, 0.0000376111] | 0.000827225 [0.000725891, 0.000938263] |
| Total measured classifier cost, USD | 0.007706664 | 0.198534 |
| Measured input tokens | 183,492 | 186,519 |
| Measured output tokens | 12,897 | 2,403 |
| Measured HTTP 200 responses | 240 / 240 | 240 / 240 |
| Provider errors / timeouts / fallback decisions | 0 / 0 / 0 | 0 / 0 / 0 |

All attempts succeeded, so the successful-only and all-attempt latency sets are identical. Wrong labels remain included in the latency and cost results

| Comparison | Estimate | 95% interval |
| --- | --- | --- |
| Mean speedup, % | 420.82 | [391.00, 451.19] |
| Mean latency reduction, % | 80.80 | [79.63, 81.86] |
| p50 speedup, % | 442.84 | [419.98, 470.51] |
| p50 latency reduction, % | 81.58 | [80.77, 82.47] |
| p95 speedup, % | 288.01 | [194.44, 378.19] |
| p95 latency reduction, % | 74.23 | [66.04, 79.09] |
| Classifier cost savings, % | 96.118 | [95.973, 96.266] |

Speedup is `100 * (Haiku_latency / JEV_latency - 1)`, calculated separately for means, medians and p95s. Latency reduction is `100 * (1 - JEV_latency / Haiku_latency)`. These are ratios of the named aggregate statistics, not averages of per-request ratios. The p50 ratio is 5.43x, not a 442.84% reduction in latency

Cost savings is `100 * (1 - sum(JEV_cost) / sum(Haiku_cost))`. All measured usage was independently repriced against the archived registry and matched the integrated router's reported cost. The versioned JEV entry charges $0.042 per million input tokens and $0 per output token. Haiku's entry charges $1 per million input tokens and $5 per million output tokens. Vendor invoices, taxes, discounts and plan entitlements were not checked

The corrected run's excluded resolution and warmup calls cost $0.002478554 at registry prices. The earlier successful resolution call is also preserved separately. None of these overhead calls is included in the comparison totals

## Authored-label quality and agreement

| Metric | Estimate | 95% interval |
| --- | --- | --- |
| JEV authored-label accuracy | 228 / 240, 95.00% | [90.00%, 98.75%] |
| Haiku authored-label accuracy | 177 / 240, 73.75% | [64.16%, 82.92%] |
| Paired accuracy difference | 21.25 percentage points | [12.92, 30.42] |
| JEV-Haiku tier agreement | 189 / 240, 78.75% | [69.58%, 87.08%] |

Agreement measures whether the classifiers return the same tier, regardless of the authored label. It is separate from quality and must not be relabeled as accuracy

| Authored tier, 20 cases / 60 attempts each | JEV accuracy [95% interval] | Haiku accuracy [95% interval] | Agreement |
| --- | --- | --- | --- |
| SIMPLE | 60 / 60, 100% [100%, 100%] | 60 / 60, 100% [100%, 100%] | 100% |
| MEDIUM | 51 / 60, 85% [70%, 100%] | 23 / 60, 38.33% [18.33%, 60%] | 53.33% |
| COMPLEX | 57 / 60, 95% [85%, 100%] | 48 / 60, 80% [60%, 95%] | 85% |
| REASONING | 60 / 60, 100% [100%, 100%] | 46 / 60, 76.67% [58.33%, 93.33%] | 76.67% |

An empirical bootstrap interval of [100%, 100%] means every sampled case in that subset matched. It is not proof of perfect accuracy on unseen cases. The effective independent case count is 80, not 240

JEV disagreed consistently on four cases across all repeats: M07, M13 and M15 were classified SIMPLE against authored MEDIUM labels, and C10 was classified MEDIUM against authored COMPLEX. Haiku's errors were predominantly assignments to a lower tier: 37 MEDIUM observations became SIMPLE, 12 COMPLEX became MEDIUM and 14 REASONING became COMPLEX. `metrics.json` contains every mismatch and full confusion matrices

| Subset | Cases / attempts per classifier | JEV accuracy | Haiku accuracy | Agreement |
| --- | --- | --- | --- | --- |
| Short | 40 / 120 | 97.50% | 73.33% | 75.83% |
| Long | 16 / 48 | 87.50% | 62.50% | 75.00% |
| Followup | 8 / 24 | 100% | 87.50% | 87.50% |
| Tool context | 8 / 24 | 100% | 83.33% | 83.33% |
| Ambiguous boundary | 8 / 24 | 87.50% | 75.00% | 87.50% |

Boundary-subset JEV accuracy has interval [62.50%, 100%], Haiku [37.50%, 100%], and the accuracy difference is 12.50 points [0, 37.50]. This subset does not establish a clear advantage at the lower interval bound. No labels or cases were changed after calls began

JEV accuracy was 95% in each repeat. Haiku was 72.50%, 75.00% and 73.75%. Per-repeat, per-tier and subset latency/cost metrics, plus all bootstrap intervals, are included in `metrics.json`

## Real gateway and persisted spend proof

The primary proof used the exact rehearsal tree, a local LiteLLM proxy, an isolated real PostgreSQL database named `jev_benchmark_final`, and real JEV and Anthropic APIs. `gateway.py` invoked curl, and `curl-evidence.md` includes the commands and sanitized JSON responses. It includes setup API calls as well as user-facing requests

All tier aliases point to the same real Haiku model to isolate routing mechanics. The selected alias is visible in persisted routing metadata. This verifies alias selection and a real downstream completion, not comparative downstream answer quality or savings between different downstream models

| Path | Observed result |
| --- | --- |
| Normal Auto Router completion | HTTP 200, JEV selected SIMPLE, `target-simple` completed using `claude-haiku-4-5-20251001` |
| Test Routing | HTTP 200, REASONING, `target-reasoning`, classifier confidence 0.97, model configured |
| Controlled deadline fallback | JEV timeout set to 1 ms, HTTP 200 downstream completion, persisted `default_model_fallback`, explicit default `target-reasoning` |
| Test Routing with zero-budget key | HTTP 400 `budget_exceeded`, zero persisted rows and zero spend for that key |

The deadline test used the real HTTP client with a deliberately tiny timeout, not a mocked response or forced exception. It demonstrates the fallback path under this timeout configuration. The persisted decision identifies fallback but does not retain the exception subtype. Logging was set to ERROR, so the timeout exception itself was not captured. No classifier usage returned for this cancellation, and the evidence cannot establish whether the provider received it or billed it

The primary normal completion's persisted downstream row cost $0.000064, exactly 14 input tokens at $0.000001 plus 10 output tokens at $0.000005. Its separate JEV row cost $0.00001806, exactly 430 input tokens at $0.000000042. The completion's routing metadata also carries that classifier cost for attribution, but its `spend` stays $0.000064, so the metadata does not add a second classifier charge

| Persisted row | Spend USD |
| --- | --- |
| Normal completion classifier | 0.000018060 |
| Normal downstream completion | 0.000064000 |
| Test Routing classifier, no downstream completion | 0.000018186 |
| Deadline-fallback downstream completion | 0.000032000 |
| Sum of four unique request IDs | 0.000132246 |
| Funded virtual key `spend` and `total_spend` | 0.000132246, within floating-point precision |

The primary completion's combined classifier plus completion cost is $0.00008206. Summing its stored row spends gives this amount once. Adding the informational `routing_decision.classifier_cost` again would double count and is incorrect

`gateway-spend-rows.json` contains the selected sanitized row fields, `gateway-key-spend.json` the funded key aggregate, and `gateway-budget-audit.json` the funded and zero-budget key audit. `gateway-audit.sql` and the SQL in `gateway.py` reproduce the queries. `verify_gateway.py` checks model usage pricing, unique rows, the expected routed aliases, the classifier cost annotation, key totals and zero-budget rows

The built-in tier defaults set downstream `max_tokens` to 64,000 in routing metadata, despite the example request supplying 24. This report records actual usage and does not treat the request's `max_tokens` as an enforced completion cap

## Setup failures and retained evidence

The initial benchmark harness attempted to combine `classifier_llm_config.system_prompt` with `tier_definitions`. Repository validation rejected that combination after one excluded JEV resolution call. The harness then used top-level `classification_prompt`, preserving the existing LLM tier bullets and trust boundary. The corpus and protocol stayed frozen, and the measured run started only after correction

The first gateway run completed all live paths and persisted spend, but the harness supplied an ignored `default_model` inside `complexity_router_config`, so timeout fallback used the automatically derived MEDIUM default. Its full evidence is retained in `gateway-initial`

A second gateway configuration tried `fallback_tier` without `tier_definitions`, which validation rejects. Test Routing returned 422 and the unregistered router completion returned 400. Its evidence is retained in `gateway-invalid-config`, with no successful classifier calls. The final run put `complexity_router_default_model` in deployment parameters and `default_model` at the top level of the Test Routing request, both supported fields. The primary proof above uses only that final run

The machine already had the project environment. A preliminary schema command used the preexisting database URL rather than the intended override and completed against the local `litellm` database. Subsequent schema commands supplied the isolated local database URL directly to the process. No parent UI environment was read or written

## Limitations and publication boundaries

Labels and examples were authored by the same agent running this comparison, with no independent annotator, adjudication or blind evaluation. This creates selection and labeling bias. Many examples are clear canonical tasks, and the largest quality difference is on the subjective MEDIUM boundary. The dataset cannot support claims of general LLM-quality equivalence, universal superiority, proof-level reasoning quality or downstream answer quality

Three repeated calls are correlated observations of the same 80 cases. Clustered bootstrap reduces false precision from counting repeated labels independently, but it cannot remove author bias or prove generalization. The short, single-client, concurrency-one run does not test saturation, sustained load, rate limits, cold starts, different regions or other provider accounts

Prices are the exact versioned repository registry values multiplied by observed token usage, not verified invoices or fresh vendor price quotations. No vendor-document pricing was used to change the registry. Tokenization, prompt wrappers and output formats differ between providers. Provider-internal caching is unknown

Gateway proof covers one simple completion, one Test Routing prompt, one controlled deadline fallback and one zero-budget denial in the primary run. It does not prove streaming, tool-call completions, custom tier names, multi-worker accounting, all authorization roles, Redis deployments, every failure mode, or invoice treatment after cancellation. Custom names were not part of the primary corpus and have no separate result

Browser/UI testing, screenshots, bot reviews, hosted CI status, merge decisions and publication are owned by the parent. No production branch was edited or pushed, no PR was opened, and no automation was enabled by this benchmark session

## Checks and artifacts

The external scripts pass isolated Ruff E/F/I checks with 120-character lines and basedpyright basic checking. The analysis validates 480 unique measured attempts, balanced tier counts, exactly three repeats per case/classifier, one upstream request per measured attempt, successful response usage and independent registry repricing. The gateway verification script passes all persisted spend assertions. These shell checks validate the evidence processing and do not replace the real API proof

`README.md` provides reproduction commands. `metrics.json` contains the full numeric report, `attempts.jsonl` every local timing and decision, and `wire.jsonl` the corresponding sanitized real requests and responses. The frozen corpus, protocol, registry, original setup records and gateway setup failures are included. The archive manifest records artifact hashes

# Reproduce the JEV classifier comparison

The archive contains observed results as well as runnable scripts. Recompute metrics without provider access using `python analyze.py`. To make new paid calls, copy the scripts, `cases.jsonl`, `protocol.json` and `freeze.json` into a fresh directory with no `attempts.jsonl`. The runner deliberately refuses to overwrite an existing attempt file

The scripts use Python 3.12, Pydantic 2, httpx, FastAPI, Uvicorn and the LiteLLM repository environment. Use the repository's existing locked dependency setup. Exact observed versions are in `environment.txt`. The gateway additionally needs curl, PostgreSQL and a generated Prisma client, as provisioned by that environment

## Reconstruct the code tree

Start from a checkout with the three input commits available

```bash
git fetch origin main litellm_jev_test_budget_1789764884 litellm_jev_autorouter_launch_1789767495
git worktree add -b "litellm_jev_reproduction_$(date +%s)" "$HOME/jev-reproduction" 1d91fc232d20a434a86323506a1303935b9c684f
git -C "$HOME/jev-reproduction" merge --no-ff --no-edit b9e5bb3abb0f2f0ddc06dcaf9edb63563cac2a2a
git -C "$HOME/jev-reproduction" merge --no-ff --no-edit 8e5f43f45897fc72612aac53a690fa573ce029cd
git -C "$HOME/jev-reproduction" rev-parse 'HEAD^{tree}'
```

The expected tree is `9dce43d6a0562a4926c39b1bacf7e9a1feac1170`. Local merge commit IDs vary with timestamps and identities. Stop if the tree differs, and do not substitute newer production tips for this historical reproduction

## Run new provider calls

Credentials must already be available through a secure environment or secret manager. The original run used `op read` to populate `TYPESAFE_API_KEY` and `ANTHROPIC_API_KEY` in memory. Never put credential values in config files, command examples, reports or archived output

```bash
export BENCHMARK_REPO="$HOME/jev-reproduction"
export PYTHONPATH="$BENCHMARK_REPO:$BENCHMARK_REPO/enterprise"
export LITELLM_LOCAL_MODEL_COST_MAP=True
python /path/to/fresh-run/benchmark.py
python /path/to/fresh-run/analyze.py
```

Port 8191 must be free. The runner resolves `jev-latest`, pins the returned version, runs four warmup pairs and then three measured repeats. A later alias may resolve differently. The archived analysis uses the observed `jev-1.13.0` registry entry, so a future version requires an explicit analysis update and must be reported as a new experiment. Preserve this archive unchanged

Do not run `freeze.py` over the historical evidence directory. It regenerates the corpus/protocol and freeze timestamp. The original authored source and expander are included so reviewers can inspect how the frozen fixtures were constructed

## Live gateway proof

Run this in an isolated local test environment, with Unix-socket PostgreSQL access for the local `ubuntu` role and an empty database named `jev_benchmark_final`. The script generates local proxy credentials in memory and redacts them from output. The default database address has no password

```bash
sudo -u postgres createdb -O ubuntu jev_benchmark_final
DATABASE_URL='postgresql://ubuntu@localhost/jev_benchmark_final?host=/var/run/postgresql' \
  prisma db push --schema "$BENCHMARK_REPO/schema.prisma" --skip-generate
python /path/to/fresh-run/gateway.py
python /path/to/fresh-run/verify_gateway.py
```

Port 8192 must be free. `gateway.py` uses the Python interpreter it was launched with, starts the real proxy with the archived model choices, invokes curl for the gateway API paths, waits for batched spend persistence, exports selected SQL fields and stops the proxy. `models.json` and `registry.json` must be in the run directory, produced by the benchmark or copied from this archive

The examples in `curl-evidence.md` replace bearer values with `$QA_KEY`. Use an authorized funded key for successful calls, a zero-budget key for the denial case and an admin key for setup. Do not reuse expired example credentials or interpret the placeholders as actual credentials

`gateway-config.json` contains environment references only. In deployment configuration, explicit fallback belongs in `litellm_params.complexity_router_default_model`. In Test Routing it belongs in the request's top-level `default_model`. The nested `default_model` attempted by the first setup run is not a supported field

## Check the evidence scripts

```bash
ruff check --isolated --select E,F,I --line-length 120 /path/to/run/*.py
basedpyright --project /path/to/run/pyrightconfig.json
python /path/to/run/analyze.py
python /path/to/run/verify_gateway.py
```

The included pyright configuration points at the original machine's virtual environment and rehearsal checkout. Update only those local paths for another environment. `verify_gateway.py` additionally queries the live isolated database, whereas the classifier analysis needs only archived files

`checks.log`, `environment.txt`, `provenance.json` and `SHA256SUMS` record the original validation and artifact identity. The two gateway setup directories and the setup-resolution JSONL files preserve unsuccessful configuration attempts without mixing them into the primary measured results

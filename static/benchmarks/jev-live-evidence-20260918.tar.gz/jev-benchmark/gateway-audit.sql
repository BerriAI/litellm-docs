
SELECT coalesce(json_agg(x), '[]'::json) FROM (
  SELECT t.key_alias, t.spend, t.total_spend, t.max_budget,
         count(s.request_id) AS spend_rows, coalesce(sum(s.spend), 0) AS sum_rows
  FROM "LiteLLM_VerificationToken" t
  LEFT JOIN "LiteLLM_SpendLogs" s ON s.api_key = t.token
  WHERE t.key_alias IN ('jev-benchmark-funded', 'jev-benchmark-zero')
  GROUP BY t.key_alias, t.spend, t.total_spend, t.max_budget ORDER BY t.key_alias
) x;
